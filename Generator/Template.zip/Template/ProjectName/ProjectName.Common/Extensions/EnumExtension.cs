﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;

namespace ProjectName.Common.Extensions
{
    /// <summary>
    /// 枚举扩展
    /// </summary>
    public static class EnumExtension
    {
        /// <summary>
        /// 获取枚举描述
        /// </summary>
        /// <param name="value">枚举值</param>
        /// <returns></returns>
        public static string GetDescription(this Enum value)
        {
            return GetEnumDescription(value);
        }

        /// <summary>
        /// 获取枚举的描述和值
        /// </summary>
        /// <typeparam name="T">枚举类型</typeparam>
        /// <returns></returns>
        public static Dictionary<string, int> GetEmunDescriptionAndValue<T>()
        {
            return GetEmunDescriptionAndValue(typeof(T));
        }

        /// <summary>
        /// 获取枚举的描述和值
        /// </summary>
        /// <param name="type">枚举类型</param>
        /// <returns></returns>
        public static Dictionary<string, int> GetEmunDescriptionAndValue(Type type)
        {
            Dictionary<string, int> list = new Dictionary<string, int>();
            if (type.IsEnum)
            {
                string[] keys = Enum.GetNames(type);
                Array values = Enum.GetValues(type);
                for (int i = 0; i < keys.Length; i++)
                {
                    list.Add(GetEnumDescription((Enum)Enum.Parse(type, keys[i])), (int)values.GetValue(i));
                }
            }
            return list;
        }

        /// <summary>
        /// 获取枚举描述
        /// </summary>
        /// <param name="value">枚举值</param>
        /// <returns></returns>
        private static string GetEnumDescription(Enum value)
        {
            FieldInfo field = value.GetType().GetField(value.ToString());
            DescriptionAttribute attribute = Attribute.GetCustomAttribute(field, typeof(DescriptionAttribute)) as DescriptionAttribute;
            return attribute == null ? value.ToString() : attribute.Description;
        }
    }
}
