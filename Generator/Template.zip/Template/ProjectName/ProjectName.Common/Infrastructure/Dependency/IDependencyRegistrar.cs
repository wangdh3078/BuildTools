﻿using Autofac;

namespace ProjectName.Common.Infrastructure.Dependency
{
    /// <summary>
    /// 实现接口实现自定义注入
    /// </summary>
    public interface IDependencyRegistrar
    {
        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="builder">容器构造器</param>
        void Register(ContainerBuilder builder);
    }
}
