﻿namespace ProjectName.Common.Infrastructure.Dependency
{
    /// <summary>
    /// 继承此接口自动实现依赖注入（单例对象）
    /// </summary>
    public interface ISingletonDependency
    {
    }
}
