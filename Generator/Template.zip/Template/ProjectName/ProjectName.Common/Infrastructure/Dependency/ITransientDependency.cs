﻿namespace ProjectName.Common.Infrastructure.Dependency
{
    /// <summary>
    /// 继承此接口自动实现依赖注入（每次创建新对象）
    /// </summary>
    public interface ITransientDependency
    {
    }
}
