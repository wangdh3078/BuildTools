﻿using Autofac;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ProjectName.Common.Infrastructure.Dependency
{
    /// <summary>
    /// 依赖注入管理
    /// </summary>
    public class IocManager
    {
        private readonly IContainer _container;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="container">容器</param>
        public IocManager(IContainer container)
        {
            _container = container;
        }

        /// <summary>
        /// 获取容器
        /// </summary>
        public virtual IContainer Container
        {
            get
            {
                return _container;
            }
        }

        /// <summary>
        /// 解析
        /// </summary>
        /// <typeparam name="T">解析类型</typeparam>
        /// <returns></returns>
        public virtual T Resolve<T>() where T : class
        {
            return _container.Resolve<T>();
        }

        /// <summary>
        /// 解析
        /// </summary>
        /// <param name="type">类型</param>
        /// <returns></returns>
        public virtual object Resolve(Type type)
        {
            return _container.Resolve(type);
        }

        /// <summary>
        /// 解析所有
        /// </summary>
        /// <typeparam name="T">类型</typeparam>
        /// <param name="key">键</param>
        /// <returns></returns>
        public virtual T[] ResolveAll<T>(string key = "")
        {
            if (string.IsNullOrEmpty(key))
            {
                return _container.Resolve<IEnumerable<T>>().ToArray();
            }
            return _container.ResolveKeyed<IEnumerable<T>>(key).ToArray();
        }

        /// <summary>
        /// 检查某些服务是否已注册（可以解析）
        /// </summary>
        /// <param name="serviceType">类型</param>
        /// <returns></returns>
        public virtual bool IsRegistered(Type serviceType)
        {
            return _container.IsRegistered(serviceType);
        }
        /// <summary>
        /// 检查某些服务是否已注册（可以解析）
        /// </summary>
        /// <param name="T">类型</param>
        /// <returns></returns>
        public virtual bool IsRegistered<T>()
        {
            return _container.IsRegistered(typeof(T));
        }
    }
}
