﻿using Autofac;
using ProjectName.Common.Infrastructure.Dependency;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace ProjectName.Common.Infrastructure
{
    public class Engine
    {
        /// <summary>
        /// 引擎实例
        /// </summary>
        public static Engine Instance { get; private set; }
        /// <summary>
        /// 依赖注入容器管理 
        /// </summary>
        public IocManager IocManager { get; private set; }

        /// <summary>
        /// 静态构造函数 确保调用是<see cref="Instance"/>一定存在
        /// </summary>
        static Engine()
        {
            Instance = new Engine();
        }
        /// <summary>
        /// 不可以通过new构造，只能通过<see cref="Instance"/>获取实例
        /// </summary>
        private Engine()
        {

        }
        /// <summary>
        /// 初始化系统基础设施
        /// </summary>
        [MethodImpl(MethodImplOptions.Synchronized)]
        public void Initialize()
        {
            RegisterDependencies();
        }
        /// <summary>
        /// 注册依赖关系
        /// </summary>
        protected virtual void RegisterDependencies()
        {
            var builder = new ContainerBuilder();

            var typeFinder = new TypeFinder();
            //注入单例类型查找
            builder.RegisterInstance(typeFinder).As<ITypeFinder>().SingleInstance();

            #region 注册实现ITransientDependency和ISingletonDependency接口的类

            var transients = typeFinder.FindClassesOfType<ITransientDependency>();
            foreach (var transient in transients)
            {
                if (!transient.IsInterface)
                {
                    builder.RegisterType(transient).InstancePerDependency();
                }
                var interfaces = transient.GetInterfaces();
                foreach (var @interface in interfaces)
                {
                    if (@interface != typeof(ITransientDependency)&& @interface != typeof(ISingletonDependency))
                    {
                        builder.RegisterType(transient).As(@interface).InstancePerDependency();
                    }
                }
            }
            var singletons = typeFinder.FindClassesOfType<ISingletonDependency>();
            foreach (var singleton in singletons)
            {
                if (!singleton.IsInterface)
                {
                    builder.RegisterType(singleton).SingleInstance();
                }
                var interfaces = singleton.GetInterfaces();
                foreach (var @interface in interfaces)
                {
                    if (@interface != typeof(ITransientDependency) && @interface != typeof(ISingletonDependency))
                    {
                        builder.RegisterType(singleton).As(@interface).InstancePerDependency();
                    }
                }
            }
            #endregion

            #region 注册实现依赖接口的类
            var drTypes = typeFinder.FindClassesOfType<IDependencyRegistrar>();
            var drInstances = new List<IDependencyRegistrar>();
            foreach (var drType in drTypes)
            {
                drInstances.Add((IDependencyRegistrar)Activator.CreateInstance(drType));
            }
            foreach (var dependencyRegistrar in drInstances)
            {
                dependencyRegistrar.Register(builder);
            }
            #endregion

            var container = builder.Build();
            IocManager = new IocManager(container);
        }
    }
}
