﻿using NLog;
using ProjectName.Model;
using System;

namespace ProjectName.Common.Log
{
    public class LogHelper
    {
        /// <summary>
        /// 日志记录器
        /// </summary>
        private readonly Logger _logger;

        /// <summary>
        /// 日志帮助类
        /// </summary>
        public static LogHelper Logger { get; private set; }

        #region 构造函数
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="logger">日志记录器</param>
        private LogHelper(Logger logger)
        {
            _logger = logger;
        }
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="name">日志记录器名称</param>
        public LogHelper(string name)
            : this(LogManager.GetLogger(name))
        {

        }
        /// <summary>
        /// 静态构造函数
        /// </summary>
        static LogHelper()
        {
            Logger = new LogHelper(LogManager.GetCurrentClassLogger());
        }
        #endregion

        #region Debug
        public void Debug(string msg)
        {
            Log(msg, LogSeverity.Debug);
        }

        public void Debug(string msg, Exception err)
        {
            Log(msg, err, LogSeverity.Debug);
        }
        #endregion

        #region Info
        public void Info(string msg)
        {
            Log(msg, LogSeverity.Info);
        }

        public void Info(string msg, Exception err)
        {
            Log(msg, err, LogSeverity.Info);
        }
        #endregion

        #region Warn
        public void Warn(string msg)
        {
            Log(msg, LogSeverity.Warn);
        }

        public void Warn(string msg, Exception err)
        {
            Log(msg, err, LogSeverity.Warn);
        }
        #endregion

        #region Trace
        public void Trace(string msg)
        {
            Log(msg, LogSeverity.Trace);
        }

        public void Trace(string msg, Exception err)
        {
            Log(msg, err, LogSeverity.Trace);
        }
        #endregion

        #region Error
        public void Error(string msg)
        {
            Log(msg, LogSeverity.Error);
        }

        public void Error(string msg, Exception err)
        {
            Log(msg, err, LogSeverity.Error);
        }
        #endregion

        #region Fatal
        public void Fatal(string msg)
        {
            Log(msg, LogSeverity.Fatal);
        }

        public void Fatal(string msg, Exception err)
        {
            Log(msg, err, LogSeverity.Fatal);
        }
        #endregion

        #region 记录日志
        /// <summary>
        /// 记录日志
        /// </summary>
        /// <param name="message">消息</param>
        /// <param name="severity">日志级别-默认Info</param>
        public void Log(string message, LogSeverity severity = LogSeverity.Info)
        {
            Log(message, string.Empty, severity);
        }

        /// <summary>
        /// 记录日志
        /// </summary>
        /// <param name="message">消息</param>
        /// <param name="exception">异常信息</param>
        /// <param name="severity">日志级别-默认Info</param>
        public void Log(string message, Exception exception, LogSeverity severity = LogSeverity.Info)
        {
            Log(message, exception, string.Empty, severity);
        }
        /// <summary>
        /// 记录日志
        /// </summary>
        /// <param name="message">消息</param>
        /// <param name="module">所属模块</param>
        /// <param name="severity">日志级别-默认Info</param>
        public void Log(string message, string module, LogSeverity severity = LogSeverity.Info)
        {
            Log(message, null, module, severity);
        }

        /// <summary>
        /// 记录日志
        /// </summary>
        /// <param name="message">消息</param>
        /// <param name="exception">异常信息</param>
        /// <param name="module">所属模块</param>
        /// <param name="severity">日志级别-默认Info</param>
        public void Log(string message, Exception exception, string module, LogSeverity severity = LogSeverity.Info)
        {
            var level = LogLevel.Info;
            switch (severity)
            {
                case LogSeverity.Trace:
                    level = LogLevel.Trace;
                    break;
                case LogSeverity.Debug:
                    level = LogLevel.Debug;
                    break;
                case LogSeverity.Info:
                    level = LogLevel.Info;
                    break;
                case LogSeverity.Warn:
                    level = LogLevel.Warn;
                    break;
                case LogSeverity.Error:
                    level = LogLevel.Error;
                    break;
                case LogSeverity.Fatal:
                    level = LogLevel.Fatal;
                    break;
            }
            var theEvent = new LogEventInfo(level, _logger.Name, message);
            var webHelper = new WebHelper();
            var ip = webHelper.GetCurrentIpAddress;
            var computerName = webHelper.GetComputerName;
            var url = webHelper.GetUrl;
            var browserInfo = webHelper.GetBrowserInfo;
            var user = webHelper.GetCurrentUser;
            theEvent.Properties["IP"] = ip;
            theEvent.Properties["ComputerName"] = computerName;
            theEvent.Properties["Url"] = url;
            theEvent.Properties["BrowserInfo"] = browserInfo;
            theEvent.Properties["Module"] = module;
            theEvent.Properties["UserId"] = user.GKey;
            theEvent.Properties["UserName"] = user.LoginName;
            theEvent.Properties["OrgCode"] = user.OrgCode;
            theEvent.Properties["OrgName"] = user.OrgName;
            theEvent.Properties["OperationDate"] = DateTime.Now;
            theEvent.Exception = exception;
            _logger.Log(theEvent);
#if DEBUG
            LogManager.Flush(); //直接写入日志（非异步），测试日志时使用，正式环境不要用
#endif
        }
        #endregion

        /// <summary>
        /// 刷新任何挂起的日志消息（在异步目标的情况下），默认超时为15秒。
        /// </summary>
        public void Flush()
        {
            LogManager.Flush();
        }
    }
}
