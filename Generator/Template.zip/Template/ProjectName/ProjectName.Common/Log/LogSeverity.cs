﻿namespace ProjectName.Common.Log
{
    /// <summary>
    /// 日志级别
    /// </summary>
    public enum LogSeverity
    {
        Trace = 1,
        Debug = 2,
        Info = 3,
        Warn = 4,
        Error = 5,
        Fatal = 6
    }
}
