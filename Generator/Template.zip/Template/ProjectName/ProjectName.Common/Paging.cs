﻿using System.Collections.Generic;

namespace ProjectName.Common
{
    /// <summary>
    /// 分页
    /// </summary>
    /// <typeparam name="T">要分页的数据类型</typeparam>
    public class Paging<T>
    {
        public Paging()
        {
            Rows = new List<T>();
        }
        /// <summary>
        /// 数据
        /// </summary>
        public IList<T> Rows { get; set; }

        /// <summary>
        /// 总数
        /// </summary>
        public int Total { get; set; }
    }
}
