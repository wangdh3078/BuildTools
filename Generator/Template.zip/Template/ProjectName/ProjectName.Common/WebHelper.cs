﻿using Newtonsoft.Json;
using ProjectName.Model;
using System;
using System.Linq;
using System.Net;
using System.Web;

namespace ProjectName.Common
{
    /// <summary>
    /// WebHelper
    /// </summary>
    public class WebHelper
    {
        /// <summary>
        ///获取URL
        /// </summary>
        /// <returns></returns>
        public string GetUrl
        {
            get
            {
                string url = string.Empty;
                try
                {
                    url = HttpContext.Current != null ? HttpContext.Current.Request.Url.ToString() : string.Empty;
                }
                catch (Exception)
                {

                }
                return url;
            }
        }
        /// <summary>
        /// 获取当前用户IP地址
        /// </summary>
        /// <returns></returns>
        public string GetCurrentIpAddress
        {
            get
            {
                var result = string.Empty;
                var httpContext = HttpContext.Current;
                try
                {
                    if (httpContext != null)
                    {

                        var forwardedHttpHeader = "X-FORWARDED-FOR";
                        string xff = HttpContext.Current.Request.Headers.AllKeys
                                   .Where(x => forwardedHttpHeader.Equals(x, StringComparison.InvariantCultureIgnoreCase))
                                   .Select(k => HttpContext.Current.Request.Headers[k])
                                   .FirstOrDefault();
                        if (!string.IsNullOrEmpty(xff))
                        {
                            string lastIp = xff.Split(new[] { ',' }).FirstOrDefault();
                            result = lastIp;
                        }
                        if (string.IsNullOrEmpty(result) && HttpContext.Current.Request.UserHostAddress != null)
                        {
                            result = HttpContext.Current.Request.UserHostAddress;
                        }
                        if (result == "::1")
                        {
                            result = "127.0.0.1";
                        }

                    }
                }
                catch (Exception)
                {

                }
                return result;
            }
        }

        /// <summary>
        /// 获取浏览器信息
        /// </summary>
        /// <returns></returns>
        public string GetBrowserInfo
        {
            get
            {
                var browserInfo = string.Empty;
                try
                {
                    var httpContext = HttpContext.Current;
                    if (httpContext == null || httpContext.Request.Browser == null)
                    {
                        return string.Empty;
                    }

                    browserInfo = httpContext.Request.Browser.Browser + "/" +
                           httpContext.Request.Browser.Version + "/" +
                           httpContext.Request.Browser.Platform;
                }
                catch (Exception)
                {

                }
                return browserInfo;
            }
        }

        /// <summary>
        /// 获取电脑名称
        /// </summary>
        /// <returns></returns>
        public string GetComputerName
        {
            get
            {
                var computerName = string.Empty;
                var httpContext = HttpContext.Current;
                try
                {
                    if (httpContext == null || !httpContext.Request.IsLocal)
                    {
                        return computerName;
                    }
                    var clientIp = httpContext.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] ??
                                   httpContext.Request.ServerVariables["REMOTE_ADDR"];
                    computerName = Dns.GetHostEntry(IPAddress.Parse(clientIp)).HostName;
                }
                catch
                {
                }
                return computerName;
            }
        }
        /// <summary>
        /// 获取当前用户信息
        /// </summary>
        /// <returns></returns>
        public User GetCurrentUser
        {
            get
            {
                User user = new User();
                try
                {
                    var httpContext = HttpContext.Current;
                    if (httpContext != null)
                    {
                        var session = HttpContext.Current.Session;
                        if (session != null && session["user"] != null)
                        {
                            user = JsonConvert.DeserializeObject<User>(session["user"].ToString());
                        }
                    }
                }
                catch (Exception)
                {

                }
                return user;
            }
        }
    }
}
