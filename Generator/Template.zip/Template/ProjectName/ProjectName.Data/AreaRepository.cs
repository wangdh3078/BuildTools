﻿using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Model;

namespace ProjectName.Data
{
    public class AreaRepository : Repository<Area>, ITransientDependency
    {

    }
}
