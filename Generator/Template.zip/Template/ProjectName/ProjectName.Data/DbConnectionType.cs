﻿using System.ComponentModel;

namespace ProjectName.Data
{
    public enum DbConnectionType
    {
        /// <summary>
        /// 基础库
        /// </summary>
        [Description("BaseConnectionString")]
        Base = 1,
        /// <summary>
        /// 业务库
        /// </summary>
        [Description("BussinessConnectionString")]
        Bussiness = 2
    }
}
