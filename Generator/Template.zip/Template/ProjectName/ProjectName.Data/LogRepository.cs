﻿using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Model;

namespace ProjectName.Data
{
    public class LogRepository : Repository<Log>, ITransientDependency
    {
    }
}
