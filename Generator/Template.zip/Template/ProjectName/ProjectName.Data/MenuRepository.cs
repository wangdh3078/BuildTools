﻿using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Model;
using System.Collections.Generic;
using System.Linq;

namespace ProjectName.Data
{
    public class MenuRepository : Repository<Menu>, ITransientDependency
    {
        /// <summary>
        /// 通过角色ID获取菜单
        /// </summary>
        /// <param name="ids">角色ID集合</param>
        /// <returns></returns>
        public List<Menu> GetMenusByRoleIds(List<string> ids)
        {
            List<Menu> list = new List<Menu>();
            list = Query(@"SELECT m.[gKey], 
		                                        m.[MenuName],
                                                m.[Url],
                                                m.[ParentId],
                                                m.[Type],
                                                m.[Sort],
                                                m.[Icon]
                                                FROM [dbo].[Permission] p
                                                INNER JOIN dbo.Menu m
                                                ON p.MenuId=m.gKey
                                                WHERE RoleId in @ids AND m.[IsEnable]=1 AND IsDelete=0", new { ids = ids })
                .Distinct(new MenuComparer()).ToList();
            return list;
        }
    }
}
