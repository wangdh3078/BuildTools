﻿using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Model;

namespace ProjectName.Data
{
    public class OrganizationRepository : Repository<Organization>, ITransientDependency
    {

        /// <summary>
        /// 获取最新机构编码
        /// </summary>
        /// <returns></returns>
        public string GetNewOrgCode()
        {
            string code = "100000";
            code = QuerySingle<string>("SELECT MAX(OrgCode)+1 FROM [Organization]");
            return code;
        }
    }
}
