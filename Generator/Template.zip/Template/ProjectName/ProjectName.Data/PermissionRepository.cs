﻿using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Model;
using System;
using System.Collections.Generic;

namespace ProjectName.Data
{
    public class PermissionRepository : Repository<Permission>, ITransientDependency
    {
        /// <summary>
        /// 保存角色权限
        /// </summary>
        /// <param name="roleId">角色ID</param>
        /// <param name="permissions">权限集合</param>
        /// <returns></returns>
        public bool SaveRolePermissions(string roleId, List<Permission> permissions)
        {
            var sucess = DB.Ado.UseTran(() =>
            {
                Execute("DELETE Permission WHERE RoleId=@roleId", new { roleId = roleId });
                Insert(permissions);
            });
            return sucess.IsSuccess;
        }
    }
}
