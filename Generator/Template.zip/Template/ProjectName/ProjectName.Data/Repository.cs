﻿using ProjectName.Common;
using ProjectName.Common.Extensions;
using ProjectName.Common.Log;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq.Expressions;

namespace ProjectName.Data
{
    /// <summary>
    /// 泛型仓储
    /// </summary>
    /// <typeparam name="TEntity">仓储对象类型</typeparam>
    public class Repository<TEntity> where TEntity : class, new()
    {
        /// <summary>
        /// 数据库类型
        /// </summary>
        protected DbConnectionType dataBaseType = DbConnectionType.Base;

        /// <summary>
        /// 构造函数
        /// </summary>
        public Repository()
        {

        }
        /// <summary>
        /// 数据库
        /// </summary>
        protected SqlSugarClient DB
        {
            get
            {
                var _connectionString = ConnectionString;
                SqlSugarClient _db = new SqlSugarClient(new ConnectionConfig()
                {
                    ConnectionString = _connectionString,//必填, 数据库连接字符串
                    DbType = DbType.SqlServer,         //必填, 数据库类型
                    IsAutoCloseConnection = true,       //默认false, 时候知道关闭数据库连接, 设置为true无需使用using或者Close操作
                    InitKeyType = InitKeyType.SystemTable    //默认SystemTable, 字段信息读取, 如：该属性是不是主键，是不是标识列等等信息
                });
                return _db;
            }
        }
        /// <summary>
        /// 数据库连接字符串
        /// </summary>
        private string ConnectionString
        {
            get
            {
                string connectionName = dataBaseType.GetDescription();
                return ConfigurationManager.ConnectionStrings[connectionName].ConnectionString;
            }
        }

        /// <summary>
        /// 添加实体
        /// </summary>
        /// <param name="entity">实体</param>
        public virtual void Insert(TEntity entity)
        {
            DB.Insertable<TEntity>(entity).ExecuteCommand();
        }
        /// <summary>
        /// 添加实体集合
        /// </summary>
        /// <param name="entities">实体集合</param>
        public virtual void Insert(List<TEntity> entities)
        {
            DB.Insertable<TEntity>(entities).ExecuteCommand();
        }
        /// <summary>
        /// 更新实体
        /// </summary>
        /// <param name="entity">实体</param>
        public virtual bool Update(TEntity entity)
        {
            try
            {
                DB.Updateable<TEntity>(entity).ExecuteCommand();
            }
            catch (Exception ex)
            {
                LogHelper.Logger.Error(ex.Message, ex);
                return false;
            }
            return true;
        }
        /// <summary>
        /// 更新实体集合
        /// </summary>
        /// <param name="entity">实体集合</param>
        public virtual bool Update(List<TEntity> entities)
        {
            try
            {
                DB.Updateable<TEntity>(entities).ExecuteCommand();
            }
            catch (Exception ex)
            {
                LogHelper.Logger.Error(ex.Message, ex);
                return false;
            }
            return true;
        }
        /// <summary>
        /// 删除实体
        /// </summary>
        /// <param name="entity">实体</param>
        public virtual bool Delete(TEntity entity)
        {
            try
            {
                DB.Deleteable<TEntity>(entity).ExecuteCommand();
            }
            catch (Exception ex)
            {
                LogHelper.Logger.Error(ex.Message, ex);
                return false;
            }
            return true;
        }
        /// <summary>
        /// 删除实体集合
        /// </summary>
        /// <param name="entities">实体</param>
        public virtual void Delete(List<TEntity> entities)
        {
            DB.Deleteable<TEntity>(entities).ExecuteCommand();
        }
        /// <summary>
        /// 根据条件删除
        /// </summary>
        /// <param name="predicate">表达式</param>
        public virtual bool Delete(Expression<Func<TEntity, bool>> predicate)
        {
            try
            {
                DB.Deleteable<TEntity>(predicate).ExecuteCommand();
            }
            catch (Exception ex)
            {
                LogHelper.Logger.Error(ex.Message, ex);
                return false;
            }
            return true;
        }

        /// <summary>
        /// 根据ID获取实体
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns> 
        public virtual TEntity Get(string id)
        {
            return DB.Queryable<TEntity>().InSingle(id);
        }

        /// <summary>
        /// 根据表达式获取实体
        /// </summary>
        /// <param name="predicate">表达式</param>
        /// <returns></returns>
        public virtual TEntity FirstOrDefault(Expression<Func<TEntity, bool>> predicate)
        {
            return DB.Queryable<TEntity>().First(predicate);
        }

        /// <summary>
        /// 获取全部数据
        /// </summary>
        /// <returns></returns>
        public virtual List<TEntity> GetAll()
        {
            return DB.Queryable<TEntity>().ToList();
        }

        /// <summary>
        /// 获取符合条件的全部数据
        /// </summary>
        /// <param name="predicate">查询表达式</param>
        /// <returns></returns>
        public virtual List<TEntity> GetAll(Expression<Func<TEntity, bool>> predicate)
        {
            return DB.Queryable<TEntity>().Where(predicate).ToList();
        }

        /// <summary>
        /// 根据SQL查询实体
        /// </summary>
        /// <param name="query">查询语句</param>
        /// <param name="parameters">参数</param>
        /// <returns></returns>
        public virtual List<TEntity> Query(string query, object parameters = null)
        {
            return DB.Ado.SqlQuery<TEntity>(query, parameters);
        }

        /// <summary>
        /// 根据SQL查询实体
        /// </summary>
        /// <param name="query">查询语句</param>
        /// <param name="parameters">参数</param>
        /// <returns></returns>
        public virtual List<T> Query<T>(string query, object parameters = null)
        {
            return DB.Ado.SqlQuery<T>(query, parameters);
        }
        /// <summary>
        /// 执行SQL查询语句返回单条记录
        /// </summary>
        /// <param name="sql">SQL</param>
        /// <param name="parameters">参数</param>
        /// <returns></returns>
        public virtual T QuerySingle<T>(string sql, object parameters = null)
        {
            return DB.Ado.SqlQuerySingle<T>(sql, parameters);
        }

        /// <summary>
        /// 执行SQL语句
        /// </summary>
        /// <param name="sql">SQL</param>
        /// <param name="parameters">参数</param>
        /// <returns></returns>
        public virtual int Execute(string sql, object parameters = null)
        {
            return DB.Ado.ExecuteCommand(sql, parameters);
        }

        /// <summary>
        /// 获取符合条件的记录数
        /// </summary>
        /// <param name="predicate">表达式</param>
        /// <returns></returns>
        public virtual int Count(Expression<Func<TEntity, bool>> predicate)
        {
            return DB.Queryable<TEntity>().Where(predicate).Count();
        }

        /// <summary>
        /// 分页获取数据-正序
        /// </summary>
        /// <param name="predicate">查询条件</param>
        /// <param name="pageSize">每页大小</param>
        /// <param name="pageIndex">当前页索引</param>
        /// <param name="sortingExpression">排序字段</param>
        /// <returns></returns> 
        public virtual Paging<TEntity> GetPaging(Expression<Func<TEntity, bool>> predicate, int pageSize, int pageIndex, Expression<Func<TEntity, object>> sortingExpression)
        {
            return GetPaging(predicate, pageSize, pageIndex, sortingExpression, true);
        }

        /// <summary>
        /// 分页获取数据--降序
        /// </summary>
        /// <param name="predicate">查询条件</param>
        /// <param name="pageSize">每页大小</param>
        /// <param name="pageIndex">当前页索引</param> 
        /// <param name="sortingExpression">排序字段</param>
        /// <returns></returns> 
        public virtual Paging<TEntity> GetPagingDesc(Expression<Func<TEntity, bool>> predicate, int pageSize, int pageIndex, Expression<Func<TEntity, object>> sortingExpression)
        {
            return GetPaging(predicate, pageSize, pageIndex, sortingExpression, false);
        }
        /// <summary>
        /// 分页获取数据
        /// </summary>
        /// <param name="predicate">查询条件</param>
        /// <param name="pageSize">每页大小</param>
        /// <param name="pageIndex">当前页索引 --从 0 开始</param> 
        /// <param name="sortingExpression">排序字段</param>
        /// <param name="ascending">是否正序</param>
        /// <returns></returns> 
        private Paging<TEntity> GetPaging(Expression<Func<TEntity, bool>> predicate, int pageSize, int pageIndex, Expression<Func<TEntity, object>> sortingExpression, bool ascending = false)
        {
            Paging<TEntity> data = new Paging<TEntity>();
            var tempData = DB.Queryable<TEntity>().Where(predicate);
            data.Total = tempData.Count();
            tempData.OrderBy(sortingExpression, ascending ? OrderByType.Asc : OrderByType.Desc);
            data.Rows = tempData.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            return data;
        }
    }
}
