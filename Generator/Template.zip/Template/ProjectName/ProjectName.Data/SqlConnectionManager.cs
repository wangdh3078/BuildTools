﻿using ProjectName.Common.Extensions;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace ProjectName.Data
{
    /// <summary>
    /// 数据库连接管理
    /// </summary>
    public class SqlConnectionManager
    {
        /// <summary>
        /// 创建数据库连接
        /// </summary>
        /// <typeparam name="T">数据库类型连接</typeparam>
        /// <param name="connectionName">连接名称</param>
        /// <returns></returns>
        private static IDbConnection CreateConnection<T>(string connectionName) where T : IDbConnection, new()
        {
            IDbConnection connection = new T
            {
                ConnectionString = ConfigurationManager.ConnectionStrings[connectionName].ConnectionString
            };
            connection.Open();
            return connection;
        }
        /// <summary>
        /// 获取指定数据库连接
        /// </summary>
        /// <param name="type">数据库连接类型</param>
        /// <returns></returns>
        public static IDbConnection GetDbConnectionInstance(DbConnectionType type)
        {
            string connectionName = type.GetDescription();
            return CreateConnection<SqlConnection>(connectionName);
        }
    }
}
