﻿using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Model;

namespace ProjectName.Data
{
    public class UserRepository : Repository<User>, ITransientDependency
    {
        public UserRepository()
        {
            //dataBaseType = DbConnectionType.Bussiness;
        }

        /// <summary>
        /// 更新密码
        /// </summary>
        /// <param name="id">用户ID</param>
        /// <param name="newPassword">新密码</param>
        /// <returns></returns>
        public bool ModifyPassword(string id, string newPassword)
        {

            bool success = false;
            success = Execute(@"UPDATE [User] SET Password=@Password ,IsUpdatePassword=1 WHERE GKey=@id",
                new { id = id, Password = newPassword }) > 0;
            return success;
        }
    }
}
