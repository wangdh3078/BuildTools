﻿using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Model;
using System.Collections.Generic;

namespace ProjectName.Data
{
    public class UserRoleRepository : Repository<UserRole>, ITransientDependency
    {
        /// <summary>
        /// 获取用户所有角色
        /// </summary>
        /// <param name="id">用户ID</param>
        /// <returns></returns>
        public List<UserRole> GetUserRoles(string id)
        {
            var sql = @"SELECT ur.*  FROM dbo.UserRole ur
                        INNER JOIN dbo.Role r
                        ON ur.RoleId=r.gKey
                        WHERE r.IsEnable=1  AND IsDelete=0  AND ur.UserId=@UserId";

            return Query(sql, new { UserId = id });
        }

        /// <summary>
        /// 保存为用户分配的角色信息
        /// </summary>
        /// <param name="userId">用户ID</param>
        /// <param name="roles">用户角色集合</param>
        /// <returns></returns>
        public bool AssignRoles(string userId, List<UserRole> roles)
        {
            var sucess = DB.Ado.UseTran(() =>
            {
                Execute("DELETE [dbo].[UserRole] WHERE  UserId=@UserId", new { UserId = userId });
                Insert(roles);
            });
            return sucess.IsSuccess;
        }
    }
}
