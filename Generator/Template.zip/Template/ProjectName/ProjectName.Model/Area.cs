﻿namespace ProjectName.Model
{
    /// <summary>
    /// 区域信息
    /// </summary>
    public class Area
    {
        /// <summary>
        /// 主键
        /// </summary>
        public string Code { get; set; } 

        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 父级ID
        /// </summary>
        public string ParentId { get; set; }

        /// <summary>
        /// 查找码
        /// </summary>
        public string Lookup { get; set; }

        /// <summary>
        /// 级别
        /// </summary>
        public int? Level { get; set; }

        /// <summary>
        /// 级别名称
        /// </summary>
        public string LevelName { get; set; }
    }
}
