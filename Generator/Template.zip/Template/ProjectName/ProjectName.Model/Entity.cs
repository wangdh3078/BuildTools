﻿using System;

namespace ProjectName.Model
{
    /// <summary>
    /// 实体基类
    /// </summary>
    public class Entity
    {
        /// <summary>
        /// 实体主键
        /// </summary>
        public string GKey { get; set; }

        /// <summary>
        /// 是否相等
        /// </summary>
        /// <param name="obj">比较对象</param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            return Equals(obj as Entity);
        }
        /// <summary>
        /// 是否临时对象
        /// </summary>
        /// <param name="obj">实体对象</param>
        /// <returns></returns>
        private static bool IsTransient(Entity obj)
        {
            return obj != null && Equals(obj.GKey, default(string));
        }
        /// <summary>
        /// 获取非代理类型
        /// </summary>
        /// <returns></returns>
        private Type GetUnproxiedType()
        {
            return GetType();
        }
        /// <summary>
        /// 是否相等
        /// </summary>
        /// <param name="other">比较对象</param>
        /// <returns></returns>
        public virtual bool Equals(Entity other)
        {
            if (other == null)
                return false;

            if (ReferenceEquals(this, other))
                return true;

            if (!IsTransient(this) &&
                !IsTransient(other) &&
                Equals(GKey, other.GKey))
            {
                var otherType = other.GetUnproxiedType();
                var thisType = GetUnproxiedType();
                return thisType.IsAssignableFrom(otherType) ||
                        otherType.IsAssignableFrom(thisType);
            }

            return false;
        }
        /// <summary>
        /// 获取哈希Code
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            if (Equals(GKey, default(int)))
                return base.GetHashCode();
            return GKey.GetHashCode();
        }
        /// <summary>
        /// 判断对象是否相等
        /// </summary>
        /// <param name="x">第一个对象</param>
        /// <param name="y">第二个对象</param>
        /// <returns></returns>
        public static bool operator ==(Entity x, Entity y)
        {
            return Equals(x, y);
        }
        /// <summary>
        /// 判断对象是否不相等
        /// </summary>
        /// <param name="x">第一个对象</param>
        /// <param name="y">第二个对象</param>
        /// <returns></returns>
        public static bool operator !=(Entity x, Entity y)
        {
            return !(x == y);
        }
    }
}
