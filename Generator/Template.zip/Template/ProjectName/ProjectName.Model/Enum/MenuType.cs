﻿using System.ComponentModel;

namespace ProjectName.Model.Enum
{
    /// <summary>
    /// 菜单类型
    /// </summary>
    public enum MenuType
    {
        /// <summary>
        /// 目录
        /// </summary>
        [Description("目录")]
        Catalog = 1,
        /// <summary>
        /// 页面
        /// </summary>
        [Description("页面")]
        Page = 2,
        /// <summary>
        /// 按钮
        /// </summary>
        [Description("按钮")]
        Button = 3
    }
}
