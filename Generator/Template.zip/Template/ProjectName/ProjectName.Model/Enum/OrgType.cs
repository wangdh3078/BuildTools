﻿using System.ComponentModel;

namespace ProjectName.Model.Enum
{
    /// <summary>
    /// 机构类型
    /// </summary>
    public enum OrganizationType
    {
        /// <summary>
        /// 政府机构
        /// </summary>
        [Description("政府机构")]
        Government = 1,
        /// <summary>
        /// 企业机构
        /// </summary>
        [Description("企业")]
        Enterprise = 2
    }
}
