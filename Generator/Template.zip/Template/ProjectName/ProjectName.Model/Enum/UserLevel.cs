﻿using System.ComponentModel;

namespace ProjectName.Model.Enum
{
    /// <summary>
    /// 用户级别
    /// </summary>
    public enum UserLevel
    {
        /// <summary>
        /// 省
        /// </summary>
        [Description("省")]
        Province = 1,
        /// <summary>
        /// 市
        /// </summary>
        [Description("市")]
        City = 2,
        /// <summary>
        /// 县/区
        /// </summary>
        [Description("县/区")]
        County = 3,
        /// <summary>
        /// 街道
        /// </summary>
        [Description("街道")]
        Street = 4
    }
}
