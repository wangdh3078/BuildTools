﻿using System;

namespace ProjectName.Model
{
    /// <summary>
    /// 日志
    /// </summary>
    public class Log : Entity
    {
        /// <summary>
        /// 消息
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// 日志级别
        /// </summary>
        public string Level { get; set; }

        /// <summary>
        /// IP地址
        /// </summary>
        public string IP { get; set; }

        /// <summary>
        /// 浏览器信息
        /// </summary>
        public string BrowserInfo { get; set; }

        /// <summary>
        /// 电脑名称
        /// </summary>
        public string ComputerName { get; set; }

        /// <summary>
        /// 请求地址
        /// </summary>
        public string Url { get; set; }
        /// <summary>
        /// 操作时间
        /// </summary>
        public DateTime OperationDate { get; set; }
        /// <summary>
        /// 操作模块
        /// </summary>
        public string Module { get; set; }

        /// <summary>
        /// 异常信息
        /// </summary>
        public string Exception { get; set; }

        /// <summary>
        /// 操作用户ID
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// 操作用户登陆名称
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 机构编码
        /// </summary>
        public string OrgCode { get; set; }

        /// <summary>
        /// 机构名称
        /// </summary>
        public string OrgName { get; set; }
    }
}
