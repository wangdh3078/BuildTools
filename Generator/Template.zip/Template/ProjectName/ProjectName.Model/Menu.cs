﻿using ProjectName.Model.Enum;
using System;
using System.Collections.Generic;

namespace ProjectName.Model
{
    public class Menu : Entity
    {
        /// <summary>
        /// 菜单名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 菜单RUL
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// 是否启用
        /// </summary>
        public bool? IsEnable { get; set; }

        /// <summary>
        /// 父级节点ID
        /// </summary>
        public string ParentId { get; set; }
        /// <summary>
        /// 菜单类型
        /// </summary>
        public MenuType? Type { get; set; }
        /// <summary>
        /// 是否删除
        /// </summary>
        public bool? IsDelete { get; set; }
        /// <summary>
        /// 菜单排序
        /// </summary>
        public int? Sort { get; set; }

        /// <summary>
        /// 图标
        /// </summary>
        public string Icon { get; set; }

        /// <summary>
        /// 菜单备注
        /// </summary>
        public string Remarks { get; set; }
        /// <summary>
        /// 添加用户ID
        /// </summary>
        public string CreateUserId { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime CreateDate { get; set; }
        /// <summary>
        /// 更新用户ID
        /// </summary>
        public string UpdateUserId { get; set; }
        /// <summary> 
        /// 更新时间
        /// </summary>
        public DateTime? UpdateDate { get; set; }
        /// <summary>
        /// 删除用户ID
        /// </summary>
        public string DeleteUserId { get; set; }
        /// <summary>
        /// 删除时间
        /// </summary>
        public DateTime? DeleteDate { get; set; }
      
    }

    /// <summary>
    /// 权限比较
    /// <remarks>
    /// 一个用户拥有多个角色时，角色可能会有重复的权限，
    /// 去除重复的权限，以免动态生成菜单时出现相同菜单
    /// </remarks>
    /// </summary>
    public class MenuComparer : EqualityComparer<Menu>
    {
        public override bool Equals(Menu x, Menu y)
        {
            if (x == null || y == null)
            {
                return false;
            }
            else
            {
                return x.GKey == y.GKey;
            }
        }
        public override int GetHashCode(Menu obj)
        {
            return obj.GKey.GetHashCode();
        }
    }
}
