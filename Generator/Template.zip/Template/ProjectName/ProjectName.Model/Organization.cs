﻿using ProjectName.Model.Enum;
using System;

namespace ProjectName.Model
{
    /// <summary>
    /// 机构
    /// </summary>
    public class Organization
    {
        /// <summary>
        /// 机构编码
        /// </summary>
        public string OrgCode { get; set; }

        /// <summary>
        /// 机构名称
        /// </summary>
        public string OrgName { get; set; }

        /// <summary>
        /// 机构类型
        /// </summary>
        public OrganizationType? OrgType { get; set; }

        /// <summary>
        /// 省份代码
        /// </summary>
        public string ProvinceCode { get; set; }
        /// <summary>
        /// 城市代码
        /// </summary>
        public string CityCode { get; set; }
        /// <summary>
        /// 县/区代码
        /// </summary>
        public string CountyCode { get; set; }

        /// <summary>
        /// 省份名称
        /// </summary>
        public string ProvinceName { get; set; }
        /// <summary>
        /// 城市名称
        /// </summary>
        public string CityName { get; set; }

        /// <summary>
        /// 县/区名称
        /// </summary>
        public string CountyName { get; set; }

        /// <summary>
        /// 用户级别（省市县街道级）
        /// </summary>
        public UserLevel? UserLevel { get; set; }
        /// <summary> 
        /// 是否启用
        /// </summary>
        public bool? IsEnable { get; set; }
        /// <summary>
        /// 是否删除
        /// </summary>
        public bool? IsDelete { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remarks { get; set; }
    
        /// <summary>
        /// 添加用户ID
        /// </summary>
        public string CreateUserId { get; set; }
        /// <summary>
        /// 添加时间
        /// </summary>
        public DateTime CreateDate { get; set; }
        /// <summary>
        /// 更新用户ID
        /// </summary>
        public string UpdateUserId { get; set; }
        /// <summary> 
        /// 更新时间
        /// </summary>
        public DateTime? UpdateDate { get; set; }
        /// <summary>
        /// 删除用户ID
        /// </summary>
        public string DeleteUserId { get; set; }
        /// <summary>
        /// 删除时间
        /// </summary>
        public DateTime? DeleteDate { get; set; }
    }
}
