﻿using System;

namespace ProjectName.Model
{
    /// <summary>
    /// 角色菜单
    /// </summary>
    public class Permission
    {
        /// <summary>
        /// 角色ID
        /// </summary> 
        public string RoleId { get; set; }

        /// <summary>
        /// 菜单ID
        /// </summary>  
        public string MenuId { get; set; }

        /// <summary>
        /// 添加用户ID
        /// </summary>
        public string CreateUserId { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime CreateDate { get; set; }
    }
}
