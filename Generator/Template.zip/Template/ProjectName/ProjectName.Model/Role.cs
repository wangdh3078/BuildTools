﻿using System;

namespace ProjectName.Model
{
    public class Role:Entity
    {
        /// <summary>
        /// 角色名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 是否启用
        /// </summary>
        public bool? IsEnable { get; set; }

        /// <summary>
        /// 是否删除
        /// </summary>
        public bool? IsDelete { get; set; }
        /// <summary>
        /// 是否显示
        /// </summary>
        public bool? IsShow { get; set; }
        /// <summary> 
        /// 角色备注
        /// </summary>
        public string Remarks { get; set; }
        /// <summary>
        /// 添加用户ID
        /// </summary>
        public string CreateUserId { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime CreateDate { get; set; }
        /// <summary>
        /// 更新用户ID
        /// </summary>
        public string UpdateUserId { get; set; }
        /// <summary> 
        /// 更新时间
        /// </summary>
        public DateTime? UpdateDate { get; set; }
        /// <summary>
        /// 删除用户ID
        /// </summary>
        public string DeleteUserId { get; set; }
        /// <summary>
        /// 删除时间
        /// </summary>
        public DateTime? DeleteDate { get; set; }
    
     
    }
}
