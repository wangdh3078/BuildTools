﻿using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Data;
using ProjectName.Model;
using System.Collections.Generic;

namespace ProjectName.Services
{
    public class AreaService : ITransientDependency
    {
        private readonly AreaRepository _areaRepository;
        public AreaService(AreaRepository areaRepository)
        {
            _areaRepository = areaRepository;
        }

        /// <summary>
        /// 获取所有区域信息
        /// </summary>
        /// <returns></returns>
        public List<Area> GetAll()
        {
            return _areaRepository.GetAll();
        }
        /// <summary>
        /// 根据父级ID获取下级地区
        /// </summary>
        /// <param name="parentId">父级ID</param>
        /// <returns></returns>
        public List<Area> GetListByParentId(string parentId)
        {
            return _areaRepository.GetAll(t => t.ParentId == parentId);
        }
    }
}
