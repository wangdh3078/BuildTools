﻿using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Data;
using ProjectName.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectName.Services
{
    public class LogServices : ITransientDependency
    {
        private readonly LogRepository _logRepository;
        public LogServices(LogRepository logRepository)
        {
            _logRepository = logRepository;
        }

        public List<Log> GetAll()
        {
            return _logRepository.GetAll();
        }
    }
}
