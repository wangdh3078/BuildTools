﻿using ProjectName.Common;
using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Data;
using ProjectName.Model;
using ProjectName.Model.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectName.Services
{
    public class MenuService : ITransientDependency
    {
        private readonly MenuRepository _menuRepository;
        public MenuService(MenuRepository menuRepository)
        {
            _menuRepository = menuRepository;
        }
        /// <summary>
        /// 添加实体
        /// </summary>
        /// <param name="menu">实体</param>
        public void Insert(Menu menu)
        {
            _menuRepository.Insert(menu);
        }
        /// <summary>
        /// 更新实体
        /// </summary>
        /// <param name="menu">实体</param>
        public void Update(Menu menu)
        {
            _menuRepository.Update(menu);
        }
        /// <summary>
        /// 根据ID获取实体
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Menu Get(string id)
        {
            return _menuRepository.Get(id);
        }
        /// <summary>
        /// 删除实体
        /// </summary>
        /// <param name="id">ID</param>
        public bool Delete(Menu menu)
        {
            var list = _menuRepository.GetAll(t => t.IsDelete == false).ToList();
            var data = GetCurrChildren(list, menu.GKey);
            data.Add(menu);
            foreach (var item in data)
            {
                item.DeleteDate = menu.DeleteDate;
                item.DeleteUserId = menu.DeleteUserId;
                item.IsDelete = true;
            }
            _menuRepository.Update(data);
            return true;
        }

        /// <summary>
        /// 获取当前菜单所有子级菜单
        /// </summary>
        /// <param name="id">菜单ID</param>
        /// <returns></returns>
        private List<Menu> GetCurrChildren(List<Menu> list, string parentId)
        {
            List<Menu> treeList = new List<Menu>();
            foreach (var item in list.Where(t => t.ParentId == parentId).OrderBy(t => t.Sort))
            {
                treeList.Add(item);
                var tempList = list.Where(t => t.ParentId == item.GKey);
                if (tempList.Count() > 0)
                {
                    treeList.AddRange(GetCurrChildren(list, item.GKey));
                }
            }
            return treeList;
        }

        /// <summary>
        /// 获取所有菜单
        /// </summary>
        /// <param name="name">菜单名称</param>
        /// <param name="state">状态</param>
        /// <returns></returns>
        public Paging<Menu> GetAllMenus(string name, bool? state)
        {
            Paging<Menu> menus = new Paging<Menu>();
            var data = _menuRepository.GetAll(t => t.IsDelete == false && t.Name.Contains(name) && t.IsEnable == state);
            //有搜索条件直接返回列表,不生成树形菜单
            if (!string.IsNullOrEmpty(name))
            {
                menus.Rows = data;
            }
            else
            {
                menus.Rows = GetList(data, "0");
                if (menus.Rows.Count == 0)
                {
                    menus.Rows = data;
                }
            }
            menus.Total = data.Count();
            return menus;
        }


        /// <summary>
        /// 生成所有子级都在父级之后的菜单列表
        /// </summary>
        /// <param name="list">菜单数据列表</param>
        /// <param name="parentId">父级ID</param>
        /// <returns></returns>
        private List<Menu> GetList(List<Menu> list, string parentId)
        {
            List<Menu> treeList = new List<Menu>();
            foreach (var item in list.Where(t => t.ParentId == parentId).OrderBy(t => t.Sort))
            {
                treeList.Add(item);
                var tempList = list.Where(t => t.ParentId == item.GKey);
                if (tempList.Count() > 0)
                {
                    treeList.AddRange(GetList(list, item.GKey));
                }
            }
            return treeList;
        }

        /// <summary>
        /// 通过角色ID获取菜单
        /// </summary>
        /// <param name="ids">角色ID集合</param>
        /// <returns></returns>
        public List<Menu> GetMenusByRoleIds(List<string> ids)
        {
            return _menuRepository.GetMenusByRoleIds(ids);
        }

        /// <summary>
        /// 获取上级菜单选项
        /// </summary>
        /// <param name="type">菜单类型</param>
        /// <param name="id">当前菜单ID</param>
        /// <returns></returns>
        public List<Menu> GetParentTreeMenu(MenuType type, string id)
        {
            List<Menu> list = new List<Menu>();
            switch (type)
            {
                case MenuType.Catalog:
                case MenuType.Page:
                    list = _menuRepository.GetAll(t => t.IsDelete == false && t.IsEnable == true && t.GKey != id && t.ParentId != id && t.Type == MenuType.Catalog);
                    break;
                case MenuType.Button:
                    list = _menuRepository.GetAll(t => t.IsDelete == false && t.IsEnable == true && t.GKey != id && t.ParentId != id && t.Type == MenuType.Button);
                    break;
            }
            list.Insert(0, (new Menu
            {
                GKey = "0",
                Name = "根目录"
            }));
            return list;
        }
        /// <summary>
        /// 禁用菜单及其所有子菜单
        /// </summary>
        /// <param name="id">菜单ID</param>
        /// <returns></returns>
        public bool DisableMenu(string id)
        {
            var list = _menuRepository.GetAll(t => t.IsDelete == false);
            var data = GetCurrChildren(list, id);
            data.Add(Get(id));
            return _menuRepository.Update(data);
        }

        /// <summary>
        /// 启用菜单
        /// </summary>
        /// <param name="id">菜单ID</param>
        /// <returns></returns>
        public bool EnableMenu(string id, out string message)
        {
            bool success = true;
            message = string.Empty;
            var menu = _menuRepository.Get(id);
            if (menu != null && menu.ParentId != "0")
            {
                var parentMenu = _menuRepository.Get(menu.ParentId);
                if (parentMenu != null && !parentMenu.IsEnable.Value)
                {
                    message = "请先启用父级节点";
                    success = false;
                }
                else
                {
                    menu.IsEnable = true;
                    success = _menuRepository.Update(menu);
                }
            }
            else
            {
                menu.IsEnable = true;
                success = _menuRepository.Update(menu);
            }
            return success;
        }
    }
}
