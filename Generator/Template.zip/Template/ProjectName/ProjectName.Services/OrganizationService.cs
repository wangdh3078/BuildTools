﻿using ProjectName.Common;
using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Data;
using ProjectName.Model;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace ProjectName.Services
{
    public class OrganizationService : ITransientDependency
    {
        private readonly OrganizationRepository _organizationRepository;
        public OrganizationService(OrganizationRepository organizationRepository)
        {
            _organizationRepository = organizationRepository;
        }

        /// <summary>
        /// 添加机构
        /// </summary>
        /// <param name="user">机构实体</param>
        public void Insert(Organization user)
        {
            _organizationRepository.Insert(user);
        }
        /// <summary>
        /// 添加机构
        /// </summary>
        /// <param name="user">机构实体</param>
        public void Insert(List<Organization> entities)
        {
            _organizationRepository.Insert(entities);
        }
        /// <summary>
        /// 更新实体
        /// </summary>
        /// <param name="user">用户实体</param>
        public bool Update(Organization user)
        {
            return _organizationRepository.Update(user);
        }
        /// <summary>
        /// 删除实体
        /// </summary>
        /// <param name="id">ID</param>
        public void Delete(string id)
        {
            _organizationRepository.Delete(t => t.OrgCode == id);
        }
        /// <summary>
        /// 根据ID获取实体
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Organization Get(string id)
        {
            return _organizationRepository.Get(id);
        }

        /// <summary>
        /// 根据表达式获取实体
        /// </summary>
        /// <param name="predicate">表达式</param>
        /// <returns></returns>
        public Organization FirstOrDefault(Expression<Func<Organization, bool>> predicate)
        {
            return _organizationRepository.FirstOrDefault(predicate);
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="pageIndex">当前页索引</param>
        /// <param name="pageSize">每页大小</param>
        /// <param name="name">机构名称</param>
        /// <param name="state">状态</param>
        /// <returns></returns>
        public Paging<Organization> GetPaging(int pageIndex, int pageSize, string name, bool? state)
        {
            return _organizationRepository.GetPaging(t => t.IsDelete == false && t.OrgName.Contains(name) && t.IsEnable == state, pageSize, pageIndex, t => t.CreateDate);
        }

        /// <summary>
        /// 根据名称是否存在
        /// </summary>
        /// <param name="name">机构名称</param>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public Organization CheckOrganizationByName(string name, string id)
        {
            return _organizationRepository.FirstOrDefault(t => t.IsDelete == false && t.OrgName == name && t.OrgCode != id);
        }

        /// <summary>
        /// 获取最新机构编码
        /// </summary>
        /// <returns></returns>
        public string GetNewOrgCode()
        {
            return _organizationRepository.GetNewOrgCode();
        }
    }
}
