﻿using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Data;
using ProjectName.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectName.Services
{
    public class PermissionService : ITransientDependency
    {
        private readonly PermissionRepository _permissionRepository;
        public PermissionService(PermissionRepository permissionRepository)
        {
            _permissionRepository = permissionRepository;
        }

        /// <summary>
        /// 根据角色ID获取权限
        /// </summary>
        /// <param name="id">角色ID</param>
        /// <returns></returns>
        public List<Permission> GetRolePermissions(string id)
        {
            return _permissionRepository.GetAll(t=>t.RoleId==id);
        }
        /// <summary>
        /// 保存角色权限
        /// </summary>
        /// <param name="roleId">角色ID</param>
        /// <param name="permissions">权限集合</param>
        /// <returns></returns>
        public bool SaveRolePermissions(string roleId, List<Permission> permissions)
        {
            return _permissionRepository.SaveRolePermissions(roleId, permissions);
        }
    }
}
