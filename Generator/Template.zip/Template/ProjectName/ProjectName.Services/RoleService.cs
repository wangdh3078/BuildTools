﻿using ProjectName.Common;
using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Data;
using ProjectName.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectName.Services
{
    public class RoleService : ITransientDependency
    {
        private readonly RoleRepository _roleRepository;
        public RoleService(RoleRepository roleRepository)
        {
            _roleRepository = roleRepository;
        }
        /// <summary>
        /// 添加实体
        /// </summary>
        /// <param name="role">实体</param>
        public void Insert(Role role)
        {
            _roleRepository.Insert(role);
        }
        /// <summary>
        /// 更新实体
        /// </summary>
        /// <param name="role">实体</param>
        public bool Update(Role role)
        {
            return _roleRepository.Update(role);
        }
        /// <summary>
        /// 删除实体
        /// </summary>
        /// <param name="id">ID</param>
        public void Delete(string id)
        {
            _roleRepository.Delete(t => t.GKey == id);
        }

        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="pageIndex">当前索引</param>
        /// <param name="pageIndex">每页大小</param>
        /// <param name="roleName">角色名称</param>
        /// <param name="state">角色状态</param>
        /// <param name="isAdmin">是否系统管理员</param>
        /// <param name="orgCode">机构编码</param>
        /// <returns></returns>
        public Paging<Role> GetPaging(int pageIndex, int pageSize, string name, bool? state, bool isAdmin, string orgCode)
        {
            return _roleRepository.GetPaging(t => t.Name.Contains(name) && t.IsDelete == false && t.IsEnable == state, pageSize, pageIndex, t => t.CreateDate);
        }
        /// <summary>
        /// 根据名称获取实体
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public Role GetRoleByName(string name)
        {
            return _roleRepository.FirstOrDefault(t => t.IsDelete == false && t.Name == name);
        }

        /// <summary>
        /// 根据ID获取实体
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public Role Get(string id)
        {
            return _roleRepository.Get(id);
        }

        /// <summary>
        /// 角色名称是否存在
        /// </summary>
        /// <param name="id">角色ID</param>
        /// <param name="name">角色名称</param>
        /// <param name="orgCode">机构编码</param>
        /// <returns></returns>
        public bool IsExistRoleName(string id, string name, string orgCode)
        {
            bool exist = false;
            var role = _roleRepository.FirstOrDefault(t => t.IsDelete == false && t.GKey != id && t.Name == name);
            if (role != null)
            {
                exist = true;
            }
            return exist;
        }

        /// <summary>
        /// 获取所有角色
        /// </summary>
        /// <returns></returns>
        public List<Role> GetAll()
        {
            return _roleRepository.GetAll(t => t.IsDelete == false && t.IsEnable == true);
        }
    }
}
