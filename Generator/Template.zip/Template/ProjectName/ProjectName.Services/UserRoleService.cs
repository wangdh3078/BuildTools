﻿using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Data;
using ProjectName.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectName.Services
{
    public class UserRoleService : ITransientDependency
    {
        private readonly UserRoleRepository _userRoleRepository;
        public UserRoleService(UserRoleRepository userRoleRepository)
        {
            _userRoleRepository = userRoleRepository;
        }
        /// <summary>
        /// 添加用户角色
        /// </summary>
        /// <param name="userRole">用户角色</param>
        public void Insert(UserRole userRole)
        {
            _userRoleRepository.Insert(userRole);
        }
        /// <summary>
        /// 根据用户ID删除角色
        /// </summary>
        /// <param name="id">用户ID</param>
        public void Delete(string id)
        {
            _userRoleRepository.Delete(t => t.UserId == id);
        }

        /// <summary>
        /// 获取用户所有角色
        /// </summary>
        /// <param name="id">用户ID</param>
        /// <returns></returns>
        public List<UserRole> GetUserRoles(string id)
        {
            return _userRoleRepository.GetUserRoles(id);
        }

        /// <summary>
        /// 保存为用户分配的角色信息
        /// </summary>
        /// <param name="userId">用户ID</param>
        /// <param name="roles">用户角色集合</param>
        /// <returns></returns>
        public bool AssignRoles(string userId, List<UserRole> roles)
        {
            return _userRoleRepository.AssignRoles(userId, roles);
        }
    }
}
