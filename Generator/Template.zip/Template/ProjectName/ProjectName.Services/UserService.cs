﻿using ProjectName.Common;
using ProjectName.Common.Infrastructure.Dependency;
using ProjectName.Data;
using ProjectName.Model;
using System.Collections.Generic;

namespace ProjectName.Services
{
    public class UserService : ITransientDependency
    {
        private readonly UserRepository _userRepository;
        public UserService(UserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        /// <summary>
        /// 添加用户
        /// </summary>
        /// <param name="user">用户实体</param>
        public void Insert(User user)
        {
            _userRepository.Insert(user);
        }
        /// <summary>
        /// 添加用户
        /// </summary>
        /// <param name="user">用户实体</param>
        public void Insert(List<User> entities)
        {
            _userRepository.Insert(entities);
        }
        /// <summary>
        /// 更新实体
        /// </summary>
        /// <param name="user">用户实体</param>
        public bool Update(User user)
        {
            return _userRepository.Update(user);
        }
        /// <summary>
        /// 删除实体
        /// </summary>
        /// <param name="id">ID</param>
        public void Delete(string id)
        {
            _userRepository.Delete(t=>t.GKey==id);
        }
        /// <summary>
        /// 根据ID获取实体
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public User Get(string id)
        {
            return _userRepository.Get(id);
        }
        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="pageIndex">当前页索引</param>
        /// <param name="pageSize">每页大小</param>
        /// <param name="name">真实姓名</param>
        /// <param name="loginName">登录名称</param>
        /// <param name="isAdmin">是否管理员</param>
        /// <param name="orgcode">机构编码</param>
        /// <param name="state">状态</param>
        /// <param name="currentUserKey">当前用户ID</param>
        /// <returns></returns>
        public Paging<User> GetPaging(int pageIndex, int pageSize, string name, string loginName, bool isAdmin, string orgcode, bool? state, string currentUserKey)
        {
            if (!isAdmin)
            {
                return _userRepository.GetPaging(t => t.IsDelete == false
                                                && t.LoginName == loginName
                                                && t.RealName == name
                                                && t.IsEnabled == state
                                                && t.GKey != currentUserKey && t.OrgCode == orgcode, pageSize, pageIndex, t => t.CreateDate);
            }
            return _userRepository.GetPaging(t => t.IsDelete == false
                                                && t.LoginName == loginName
                                                && t.RealName == name
                                                && t.IsEnabled == state
                                                && t.GKey != currentUserKey, pageSize, pageIndex, t => t.CreateDate);
        }
        /// <summary>
        /// 根据名称获取用户
        /// </summary>
        /// <param name="name">用户名</param>
        /// <returns></returns>
        public User GetUserByName(string name)
        {
            return _userRepository.FirstOrDefault(t => t.IsDelete == false && t.LoginName == name);
        }
        /// <summary>
        /// 根据用户名检查用户是否存在
        /// </summary>
        /// <param name="name">用户名</param>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public bool CheckUserByName(string name, string id)
        {
            bool exist = false;
            var user = _userRepository.FirstOrDefault(t => t.IsDelete == false && t.LoginName == name && t.GKey != id);
            if (user != null)
            {
                exist = true;
            }
            return exist;
        }

        /// <summary>
        /// 验证登录
        /// </summary>
        /// <param name="name">登陆名</param>
        /// <param name="password">密码</param>
        /// <returns></returns>
        public User CheckLogin(string name, string password)
        {
            password = CryptoHelper.MD5Encrypt(password);
            return _userRepository.FirstOrDefault(t => t.IsDelete == false && t.LoginName == name && t.Password == password);
        }
        /// <summary>
        /// 更新密码
        /// </summary>
        /// <param name="id">用户ID</param>
        /// <param name="newPassword">新密码</param>
        /// <returns></returns>
        public bool ModifyPassword(string id, string newPassword)
        {
            newPassword = CryptoHelper.MD5Encrypt(newPassword);
            return _userRepository.ModifyPassword(id, newPassword);
        }
    }
}
