﻿layui.define(['layer'], function (exports) {
    var $ = layui.$;
    var login = {
        login: function (data) {
            $.ajax({
                url: "/Auth/Login",
                data: data,
                type: "POST",
                success: function (data) {
                    if (data.success) {
                        layer.msg('登录成功', {
                            icon: 1,
                            time: 1000
                        }, function () {
                            location.href = '/Home';
                        });
                    } else {
                        layer.msg(data.message);
                    }
                },
                error: function (data) {
                    console.log(data);
                }
            });
        }
    };
    exports('login', login);
});