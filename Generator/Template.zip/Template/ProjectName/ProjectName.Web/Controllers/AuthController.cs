﻿using Newtonsoft.Json;
using ProjectName.Common.Log;
using ProjectName.Services;
using System.Web.Mvc;
using System;

namespace ProjectName.Web.Controllers
{

    public class AuthController : Controller
    {
        private readonly UserService _userService;

        public AuthController(UserService userService)
        {
            _userService = userService;
        }
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// 登陆验证
        /// </summary>
        /// <param name="name">登陆名</param>
        /// <param name="password">密码</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Login(string name, string password)
        {
            bool success = false;
            string message = string.Empty;
            var user = _userService.GetUserByName(name);
            if (user != null)
            {
                user = _userService.CheckLogin(name, password);
                if (user != null)
                {
                    if (user.IsEnabled == true)
                    {

                        Session["user"] = JsonConvert.SerializeObject(user);
                        success = true;
                        message = "登陆成功";
                        LogHelper.Logger.Log(string.Format("【{0}】登陆系统", user.LoginName));
                    }
                    else
                    {
                        message = "账号已被禁用！";
                    }
                }
                else
                {
                    message = "密码错误！";
                }
            }
            else
            {
                message = "用户名不存在！";
            }
            return Json(new
            {
                success = success,
                message = message
            });
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <returns></returns>
        public ActionResult LogOff()
        {
            Session.Clear();
            Session["user"] = null;
            return RedirectToAction("Index", "Auth");
        }
        /// <summary>
        /// 清除session
        /// </summary>
        public void ClearSession()
        {
            Session["user"] = null;
            Session["areaList"] = null;
        }
    }
}