﻿using Newtonsoft.Json;
using ProjectName.Common.Infrastructure;
using ProjectName.Common.Log;
using ProjectName.Model;
using ProjectName.Web.Filter;
using System;
using System.Web.Mvc;
using Autofac;
using ProjectName.Services;

namespace ProjectName.Web.Controllers
{
    /// <summary>
    /// 基类控制器
    /// </summary>
    [Authentication]
    public class BaseController : Controller
    {
        public User CurrentUser
        {
            get
            {
                User user = null;
                if (Session["user"] != null)
                {
                    user = new User();
                    try
                    {
                        user = JsonConvert.DeserializeObject<User>(Session["user"].ToString());
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Logger.Error(ex.Message, ex);
                        throw ex;
                    }
                }
                return user;
            }
        }

        public Organization CurrentUserOrgInfo
        {
            get
            {
                Organization org = null;
                var user = CurrentUser;
                if (user != null)
                {
                    try
                    {
                        org = Engine.Instance.IocManager.Container.Resolve<OrganizationService>().Get(user.OrgCode);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
                return org;
            }
        }
    }
}