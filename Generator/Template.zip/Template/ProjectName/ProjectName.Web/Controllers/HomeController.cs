﻿using Newtonsoft.Json;
using ProjectName.Common.Log;
using ProjectName.Model;
using ProjectName.Services;
using ProjectName.Web.Filter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProjectName.Web.Controllers
{
    public class HomeController : BaseController
    {
        private readonly UserService _userService;
        public HomeController(UserService userService)
        {
            _userService = userService;
        }

        [OperationLog("系统首页")]
        public ActionResult Index()
        {
            ViewBag.UserName = CurrentUser.RealName;
            return View();
        }

        public ActionResult Main()
        {
            return View();
        }
    }
}