﻿using Newtonsoft.Json;
using ProjectName.Services;
using ProjectName.Web.Extensions;
using ProjectName.Web.Filter;
using ProjectName.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProjectName.Web.Controllers
{
    [Authentication]
    public class OrganizationController : BaseController
    {
        private readonly OrganizationService _organizationService;
        public OrganizationController(OrganizationService organizationService)
        {
            _organizationService = organizationService;
        }
        // GET: Organization
        public ActionResult Index()
        {
            return View();
        }

        #region 添加/编辑
        /// <summary>
        /// 添加或编辑机构信息
        /// </summary>
        /// <param name="id">机构ID</param>
        /// <returns></returns>
        public ActionResult AddOrEdit(string id)
        {
            OrganizationViewModel organizationViewModel = new OrganizationViewModel();
            return View(organizationViewModel);
        }
        /// <summary>
        /// 保存机构信息
        /// </summary>
        /// <param name="model">机构信息实体</param>
        /// <returns></returns>

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult AddOrEdit(OrganizationViewModel model)
        {
            bool success = false;
            string message = string.Empty;
            Dictionary<string, string> dicError = null;
            if (ModelState.IsValid)
            {
                if (model.OrgCode.Trim() != "自动生成")
                {
                    var org = _organizationService.Get(model.OrgCode);
                    success = true;
                    message = "保存成功";
                }
                else
                {
                    success = true;
                    message = "保存成功";
                }
            }
            else
            {
                dicError = ModelState.ModelErrorToDictionary();
            }
            return Json(new { success = success, message = JsonConvert.SerializeObject(dicError) ?? message });
        }
        #endregion
    }
}