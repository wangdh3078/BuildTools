﻿using Autofac;
using Autofac.Integration.Mvc;
using ProjectName.Common.Infrastructure.Dependency;
using System.Reflection;

namespace ProjectName.Web
{
    /// <summary>
    /// 实现依赖注入接口
    /// </summary>
    public class DependencyRegistrar : IDependencyRegistrar
    {
        /// <summary>
        /// 注入
        /// </summary>
        /// <param name="builder">注入容器构造器</param>
        public void Register(ContainerBuilder builder)
        {
            //注入API控制器
            builder.RegisterControllers(Assembly.GetExecutingAssembly());
        }
    }
}