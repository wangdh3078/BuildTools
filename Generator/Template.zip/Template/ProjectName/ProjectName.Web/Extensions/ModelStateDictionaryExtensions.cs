﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace ProjectName.Web.Extensions
{
    /// <summary>
    /// 模型验证扩展
    /// </summary>
    public static class ModelStateDictionaryExtensions
    {
        /// <summary>
        /// 错误信息转换成字典
        /// </summary>
        /// <param name="modelStateDictionary">错误信息</param>
        /// <returns>{字段名称：错误信息，字段名称2：错误信息}</returns>
        public static Dictionary<string, string> ModelErrorToDictionary(this ModelStateDictionary modelStateDictionary)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            foreach (var item in modelStateDictionary)
            {
                if (item.Value.Errors.Count > 0)
                {
                    dic.Add(item.Key, item.Value.Errors[0].ErrorMessage);
                }
            }
            return dic;
        }
    }
}