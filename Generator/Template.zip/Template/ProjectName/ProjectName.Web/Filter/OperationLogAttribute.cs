﻿using ProjectName.Common.Log;
using System;
using System.Web.Mvc;

namespace ProjectName.Web.Filter
{
    /// <summary>
    /// 记录操作记录
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
    public class OperationLogAttribute : ActionFilterAttribute
    {
        private string _actionDescriptor;
        /// <summary>
        /// 构造函数
        /// </summary>
        public OperationLogAttribute()
        {

        }
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="actionDescriptor">Action中文描述</param>
        public OperationLogAttribute(string actionDescriptor)
        {
            _actionDescriptor = actionDescriptor;
        }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var controllerName = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
            LogHelper.Logger.Log(_actionDescriptor, controllerName);
            base.OnActionExecuting(filterContext);
        }
    }
}