﻿using Autofac.Integration.Mvc;
using FluentValidation;
using FluentValidation.Mvc;
using ProjectName.Common.Infrastructure;
using ProjectName.Common.Log;
using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace ProjectName.Web
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
           // LogHelper.Logger.Info("应用程序启动...");

            //初始化系统基础设施
            Engine.Instance.Initialize();
            //设置依赖解析器
            DependencyResolver.SetResolver(new AutofacDependencyResolver(Engine.Instance.IocManager.Container));
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            /* 比如验证用户名 not null、not empty、length(2,int.MaxValue) 时，链式验证时，如果第一个验证失败，则停止验证 */
            ValidatorOptions.CascadeMode = CascadeMode.StopOnFirstFailure;
            // 配置 FluentValidation 模型验证为默认的 ASP.NET MVC 模型验证
            FluentValidationModelValidatorProvider.Configure();
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            var exception = Server.GetLastError();
            LogHelper.Logger.Error(exception.Message, exception);
        }
    }
}
