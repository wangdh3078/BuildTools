﻿using FluentValidation.Attributes;
using ProjectName.Model.Enum;
using ProjectName.Web.Validators;

namespace ProjectName.Web.Models
{
    [Validator(typeof(OrganizationViewModelValidator))]
    public class OrganizationViewModel
    {
        /// <summary>
        /// 机构编码
        /// </summary>
        public string OrgCode { get; set; }
        /// <summary>
        /// 机构名称
        /// </summary>
        public string OrgName { get; set; }
        /// <summary>
        /// 机构类型
        /// </summary>
        public OrganizationType? OrganizationType { get; set; }
        /// <summary>
        /// 省份代码
        /// </summary>
        public string ProvinceCode { get; set; }
        /// <summary>
        /// 城市代码
        /// </summary>
        public string CityCode { get; set; }
        /// <summary>
        /// 县/区代码
        /// </summary>
        public string CountyCode { get; set; }
     
        /// <summary>
        /// 省份名称
        /// </summary>
        public string ProvinceName { get; set; }
        /// <summary>
        /// 城市名称
        /// </summary>
        public string CityName { get; set; }

        /// <summary>
        /// 县/区名称
        /// </summary>
        public string CountyName { get; set; }
      
        /// <summary>
        /// 用户级别（省市县街道级）
        /// </summary>
        public UserLevel? UserLevel { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
        /// <summary>
        /// 是否启用
        /// </summary>
        public bool? IsEnable { get; set; }
    }
}