﻿using FluentValidation;
using ProjectName.Common.Infrastructure;
using ProjectName.Services;
using ProjectName.Web.Models;

namespace ProjectName.Web.Validators
{
    public class OrganizationViewModelValidator : AbstractValidator<OrganizationViewModel>
    {
        public OrganizationViewModelValidator()
        {
            RuleFor(t => t.OrgName).NotEmpty().WithMessage("机构名称不能为空！")
                .Must(IsExistOrganizationName).WithMessage("机构名称已存在");
        }
        /// <summary>
        /// 验证名称是否已存在
        /// </summary>
        /// <param name="organization">机构实体</param>
        /// <param name="name">用户名</param>
        /// <returns></returns>
        private bool IsExistOrganizationName(OrganizationViewModel organization, string name)
        {
            bool valid = true;
            var _userService = Engine.Instance.IocManager.Resolve<OrganizationService>();
            var _user = _userService.CheckOrganizationByName(organization.OrgName, organization.OrgCode);
            if (_user != null)
            {
                valid = false;
            }
            return valid;
        }
    }
}